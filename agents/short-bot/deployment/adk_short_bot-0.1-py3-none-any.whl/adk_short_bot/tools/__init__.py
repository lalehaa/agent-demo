from .character_counter import count_characters

__all__ = ["count_characters"]
